package net.voicemaster.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
